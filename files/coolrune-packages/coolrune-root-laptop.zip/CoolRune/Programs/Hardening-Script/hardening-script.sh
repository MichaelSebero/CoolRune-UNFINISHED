#!/bin/bash
su -c '
# Function for applying config files with improved error handling
apply_config() {
    local source_file="confs/$1"
    local target_file="$2"
    
    if [ ! -f "$source_file" ]; then
        echo "Warning: Configuration file $source_file not found - skipping"
        return 0
    fi
    
    if ! cat "$source_file" > "$target_file" 2>/dev/null; then
        echo "Warning: Failed to apply $source_file to $target_file - skipping"
        return 0
    fi
    
    echo "Successfully applied $source_file to $target_file"
    return 0
}

echo "Starting laptop-focused system hardening process..."

# Set secure file permissions
echo "Setting secure file permissions..."
chmod 700 /root
chmod 600 /etc/shadow
chmod 600 /etc/gshadow
chmod 600 /etc/passwd   # More restrictive than original
chmod 600 /etc/group    # More restrictive than original
chmod 600 /etc/sudoers
chmod -R 700 /etc/ssl/private
chmod -R 755 /etc/ssl/certs

# UFW Configuration
echo "Configuring UFW with strict rules..."
ufw reset
ufw default deny incoming
ufw default deny outgoing  # Start with deny all outgoing, then allow specific
# Essential outbound
ufw allow out 53/udp   # DNS
ufw allow out 80/tcp   # HTTP
ufw allow out 443/tcp  # HTTPS
# P2P ports (restricted set)
ufw allow out 6881:6889/tcp  # BitTorrent
ufw allow out 6881:6889/udp
ufw allow 6881:6889/tcp  # Allow incoming P2P
ufw allow 6881:6889/udp
# Steam
ufw allow out 27000:27100/tcp
ufw allow out 27000:27100/udp
ufw allow 27000:27100/tcp
ufw allow 27000:27100/udp
# PlayStation/Xbox
ufw allow out 3478:3480/tcp
ufw allow out 3478:3480/udp
ufw allow 3478:3480/tcp
ufw allow 3478:3480/udp
# Tor network
ufw allow out 9050/tcp
ufw allow out 9051/tcp
ufw allow out 9150/tcp
ufw allow 9050/tcp
ufw allow 9051/tcp
ufw allow 9150/tcp
# GitHub
ufw allow out 22/tcp   # Git SSH
ufw allow out 9418/tcp # Git protocol
ufw allow out 443/tcp  # HTTPS
ufw enable

# System control parameters
echo "Configuring system control parameters..."
sysctl -a
sysctl -A
sysctl mib
sysctl net.ipv4.conf.all.rp_filter
sysctl -a --pattern "net\\.ipv4\\.conf\\.(eth|wlan)0\\.arp"

# Host configuration
cat <<EOF > /etc/host.conf
order bind,hosts
multi on
EOF

# Display listening ports
echo "Current listening ports:"
netstat -tunlp

# Initialize firewall variables
IPTABLES="/sbin/iptables"
IP6TABLES="/sbin/ip6tables"
MODPROBE="/sbin/modprobe"
RMMOD="/sbin/rmmod"
ARP="/usr/sbin/arp"
SSHPORT="22"

# Logging configuration
LOG="LOG --log-level debug --log-tcp-sequence --log-tcp-options"
LOG="$LOG --log-ip-options"

# Rate limiting defaults
RLIMIT="-m limit --limit 3/s --limit-burst 8"

# Port ranges
PHIGH="1024:65535"
PSSH="1000:1023"

# Load required modules
"$MODPROBE" ip_conntrack_ftp
"$MODPROBE" ip_conntrack_irc

# Enhanced SSH configuration with modern crypto
if [ -f "/etc/ssh/sshd_config" ]; then
    echo "Hardening SSH configuration..."
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    cat > /etc/ssh/sshd_config << EOF
Port 22
Protocol 2
PermitRootLogin no
MaxAuthTries 3
PubkeyAuthentication yes
PasswordAuthentication no
PermitEmptyPasswords no
X11Forwarding no
AllowTcpForwarding no
AllowAgentForwarding no
PermitTunnel no
MaxStartups 3:50:10
LoginGraceTime 30
ClientAliveInterval 180
ClientAliveCountMax 3
UsePAM yes
AllowUsers *@192.168.* *@10.* # Only allow local network connections
Compression no
KexAlgorithms curve25519-sha256@libssh.org,curve25519-sha256
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com
MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com
EOF
fi

# Ignore ICMP broadcast requests
net.ipv4.icmp_echo_ignore_broadcasts = 1

# Disable source packet routing
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0

# Ignore send redirects
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0

# Block SYN attacks
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 2048
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 5

# Log Martians
net.ipv4.conf.all.log_martians = 1
net.ipv4.conf.default.log_martians = 1

# Ignore ICMP redirects
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.secure_redirects = 0

# Ignore bogus ICMP responses
net.ipv4.icmp_ignore_bogus_error_responses = 1

# Protect against time-wait assassination
net.ipv4.tcp_rfc1337 = 1

# Enable ExecShield protection
kernel.exec-shield = 2
kernel.randomize_va_space = 2

# Protect against kernel pointer leaks
kernel.kptr_restrict = 2

# Restrict dmesg access
kernel.dmesg_restrict = 1

# Protect against user namespaces
kernel.unprivileged_userns_clone = 0

# Protect against kernel exploits
kernel.kexec_load_disabled = 1
EOF

# Initialize enhanced iptables configuration
echo "Configuring strict iptables rules..."
"$IPTABLES" -F
"$IPTABLES" -X
"$IPTABLES" -Z

# Default policy
"$IPTABLES" -P INPUT DROP
"$IPTABLES" -P FORWARD DROP
"$IPTABLES" -P OUTPUT DROP

# Configure NAT/mangle tables
"$IPTABLES" -t nat -P PREROUTING ACCEPT
"$IPTABLES" -t nat -P OUTPUT ACCEPT
"$IPTABLES" -t nat -P POSTROUTING ACCEPT

"$IPTABLES" -t mangle -P PREROUTING ACCEPT
"$IPTABLES" -t mangle -P INPUT ACCEPT
"$IPTABLES" -t mangle -P FORWARD ACCEPT
"$IPTABLES" -t mangle -P OUTPUT ACCEPT
"$IPTABLES" -t mangle -P POSTROUTING ACCEPT

# Clean existing rules
"$IPTABLES" -t nat -F
"$IPTABLES" -t mangle -F
"$IPTABLES" -t nat -X
"$IPTABLES" -t mangle -X
"$IPTABLES" -t nat -Z
"$IPTABLES" -t mangle -Z

# Custom chains for logging
"$IPTABLES" -N ACCEPTLOG
"$IPTABLES" -A ACCEPTLOG -j "$LOG" "$RLIMIT" --log-prefix "ACCEPT "
"$IPTABLES" -A ACCEPTLOG -j ACCEPT

"$IPTABLES" -N DROPLOG
"$IPTABLES" -A DROPLOG -j "$LOG" "$RLIMIT" --log-prefix "DROP "
"$IPTABLES" -A DROPLOG -j DROP

"$IPTABLES" -N REJECTLOG
"$IPTABLES" -A REJECTLOG -j "$LOG" "$RLIMIT" --log-prefix "REJECT "
"$IPTABLES" -A REJECTLOG -p tcp -j REJECT --reject-with tcp-reset
"$IPTABLES" -A REJECTLOG -j REJECT

# Allow loopback
"$IPTABLES" -A INPUT -i lo -j ACCEPT
"$IPTABLES" -A OUTPUT -o lo -j ACCEPT

# Allow established connections
"$IPTABLES" -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
"$IPTABLES" -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# Allow essential outbound services
"$IPTABLES" -A OUTPUT -p tcp --dport 80 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A OUTPUT -p tcp --dport 443 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A OUTPUT -p udp --dport 53 -m conntrack --ctstate NEW -j ACCEPT

# P2P rules with rate limiting
"$IPTABLES" -A OUTPUT -p tcp --dport 6881:6889 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A OUTPUT -p udp --dport 6881:6889 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --dport 6881:6889 -m conntrack --ctstate NEW -m limit --limit 1/s --limit-burst 10 -j ACCEPT
"$IPTABLES" -A INPUT -p udp --dport 6881:6889 -m conntrack --ctstate NEW -m limit --limit 1/s --limit-burst 10 -j ACCEPT

# Gaming rules
"$IPTABLES" -A OUTPUT -p tcp --dport 27000:27100 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A OUTPUT -p udp --dport 27000:27100 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --dport 27000:27100 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A INPUT -p udp --dport 27000:27100 -m conntrack --ctstate NEW -j ACCEPT

"$IPTABLES" -A OUTPUT -p tcp --dport 3478:3480 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A OUTPUT -p udp --dport 3478:3480 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --dport 3478:3480 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A INPUT -p udp --dport 3478:3480 -m conntrack --ctstate NEW -j ACCEPT

# Tor Network
"$IPTABLES" -A OUTPUT -p tcp --dport 9050 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A OUTPUT -p tcp --dport 9051 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A OUTPUT -p tcp --dport 9150 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --dport 9050 -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --dport 9051 -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --dport 9150 -j ACCEPT

# GitHub
"$IPTABLES" -A OUTPUT -p tcp --dport 22 -m conntrack --ctstate NEW -j ACCEPT
"$IPTABLES" -A OUTPUT -p tcp --dport 9418 -m conntrack --ctstate NEW -j ACCEPT

# Enhanced DDoS protection
"$IPTABLES" -A INPUT -p tcp --syn -m limit --limit 1/s --limit-burst 3 -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --syn -j DROP
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL NONE -m limit --limit 1/h -j ACCEPT
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL ALL -m limit --limit 1/h -j ACCEPT

# Block suspicious packets
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL NONE -j DROP
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL ALL -j DROP
"$IPTABLES" -A INPUT -f -j DROP  # Block fragmented packets
"$IPTABLES" -A INPUT -p tcp ! --syn -m state --state NEW -j DROP
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL NONE -j DROP

# Advanced brute force protection
"$IPTABLES" -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW -m recent --set
"$IPTABLES" -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW -m recent --update --seconds 60 --hitcount 4 -j DROP

# Add logging for failed connection attempts
"$IPTABLES" -A INPUT -m limit --limit 5/min -j LOG --log-prefix "iptables_INPUT_denied: " --log-level 7

# Explicitly log and reject everything else
"$IPTABLES" -A INPUT -j REJECTLOG
"$IPTABLES" -A FORWARD -j REJECTLOG

# Save rules
iptables-save > /etc/iptables/rules.v4

# Disable uncommon network protocols
echo "Disabling uncommon network protocols..."
cat >> /etc/modprobe.d/uncommon-net-protocols.conf << EOF
install dccp /bin/true
install sctp /bin/true
install rds /bin/true
install tipc /bin/true
install n-hdlc /bin/true
install ax25 /bin/true
install netrom /bin/true
install x25 /bin/true
install rose /bin/true
install decnet /bin/true
install econet /bin/true
install af_802154 /bin/true
install ipx /bin/true
install appletalk /bin/true
install psnap /bin/true
install p8023 /bin/true
install p8022 /bin/true
install can /bin/true
install atm /bin/true
EOF

# Additional system hardening
echo "Applying additional system hardening..."

# Secure /tmp and /var/tmp
echo "Securing temporary directories..."
mount -o remount,noexec,nosuid,nodev /tmp
mount -o remount,noexec,nosuid,nodev /var/tmp

# Verify important file permissions
echo "Verifying critical file permissions..."
find /etc/cron.* -type f -exec chmod 0700 {} \;
chmod 0600 /etc/crontab
chmod 0600 /etc/ssh/sshd_config 2>/dev/null
chmod -R 0700 /etc/ssl/private 2>/dev/null

# Disable uncommon filesystems
echo "Disabling uncommon filesystems..."
cat >> /etc/modprobe.d/uncommon-filesystems.conf << EOF
install cramfs /bin/true
install freevxfs /bin/true
install jffs2 /bin/true
install hfs /bin/true
install hfsplus /bin/true
install squashfs /bin/true
install udf /bin/true
EOF

# Apply system configuration changes
echo "Applying system changes..."
sysctl -p

# Secure su by limiting to wheel group
echo "auth required pam_wheel.so use_uid" >> /etc/pam.d/su

# Apply hardened configuration files
echo "Applying Hardened configuration files..."
apply_config "etc-aide-conf" "/etc/aide.conf"
apply_config "etc-bash-bashrc" "/etc/bash.bashrc"
apply_config "etc-crypttab" "/etc/crypttab"
apply_config "etc-default-passwd" "/etc/default/passwd"
apply_config "etc-dhclient-conf" "/etc/dhclient.conf"
apply_config "etc-hardening-wrapper-conf" "/etc/hardening-wrapper.conf"
apply_config "etc-iptables-ip6tables.rules" "/etc/iptables/ip6tables.rules"
apply_config "etc-iptables-iptables.rules" "/etc/iptables/iptables.rules"
apply_config "etc-issue" "/etc/issue"
apply_config "etc-issue-net" "/etc/issue.net"
apply_config "etc-locale-conf" "/etc/locale.conf"
apply_config "etc-locale-gen" "/etc/locale.gen"
apply_config "etc-mkinitcpio-conf" "/etc/mkinitcpio.conf"
apply_config "etc-modprobe-d-blacklist-firewire" "/etc/modprobe.d/blacklist-firewire"

# Laptop-specific security enhancements
echo "Applying laptop-specific security measures..."

# Power management security
cat >> /etc/systemd/sleep.conf << EOF
AllowSuspend=yes
AllowHibernation=no
AllowSuspendThenHibernate=no
AllowHybridSleep=no
EOF

# Disable Wake-on-LAN
ethtool -s eth0 wol d 2>/dev/null
ethtool -s wlan0 wol d 2>/dev/null

# Secure wireless settings
cat >> /etc/NetworkManager/conf.d/wifi-security.conf << EOF
[connection]
wifi.mac-address-randomization=1

[device]
wifi.scan-rand-mac-address=yes
EOF

# Enhanced disk encryption warning
echo "ENCRYPT_METHOD SHA512" >> /etc/login.defs
echo "Disk encryption is strongly recommended for laptop systems" > /etc/issue.net

# Create backup of final configuration
BACKUP_DIR="/root/security_backup_$(date +%Y%m%d_%H%M%S)"
echo "Creating security configuration backup in $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
cp -p /etc/ssh/sshd_config "$BACKUP_DIR/" 2>/dev/null
cp -p /etc/sysctl.conf "$BACKUP_DIR/"
cp -p /etc/security/limits.conf "$BACKUP_DIR/"
iptables-save > "$BACKUP_DIR/iptables_backup"

# Display completion message with timestamp
echo "Enhanced laptop hardening configuration completed at $(date)"
echo "System is now hardened with the following features:"
echo "- Strict firewall rules with P2P, gaming, Tor, and GitHub access"
echo "- Enhanced brute force protection"
echo "- Restricted remote access"
echo "- System hardening optimized for laptop use"
echo "- MAC address randomization for WiFi"
echo "- Disabled Wake-on-LAN"
echo "- Secure power management settings"
echo "Please review any warnings above and reboot the system when convenient."
echo "Note: Some changes require a system restart to take effect."

exit 0
'
