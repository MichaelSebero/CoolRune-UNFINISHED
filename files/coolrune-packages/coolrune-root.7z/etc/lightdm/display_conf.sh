#!/bin/sh
xrandr --output HDMI1 -- mode 1920x1080
