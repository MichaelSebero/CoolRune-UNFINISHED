#!/bin/bash
su -c '
# Function for applying config files with improved error handling
apply_config() {
    local source_file="confs/$1"
    local target_file="$2"
    
    if [ ! -f "$source_file" ]; then
        echo "Warning: Configuration file $source_file not found - skipping"
        return 0
    fi
    
    if ! cat "$source_file" > "$target_file" 2>/dev/null; then
        echo "Warning: Failed to apply $source_file to $target_file - skipping"
        return 0
    fi
    
    echo "Successfully applied $source_file to $target_file"
    return 0
}

echo "Starting system hardening process..."

# Set secure file permissions
echo "Setting secure file permissions..."
chmod 700 /root
chmod 600 /etc/shadow
chmod 600 /etc/gshadow
chmod 644 /etc/passwd
chmod 644 /etc/group
chmod 600 /etc/sudoers
chmod -R 700 /etc/ssl/private
chmod -R 755 /etc/ssl/certs

# UFW Configuration
echo "Configuring UFW..."
ufw limit 22/tcp  
ufw allow 80/tcp  
ufw allow 443/tcp  
ufw default deny incoming  
ufw default allow outgoing
ufw enable

# System control parameters
echo "Configuring system control parameters..."
sysctl -a
sysctl -A
sysctl mib
sysctl net.ipv4.conf.all.rp_filter
sysctl -a --pattern "net\\.ipv4\\.conf\\.(eth|wlan)0\\.arp"

# Host configuration
cat <<EOF > /etc/host.conf
order bind,hosts
multi on
EOF

# Display listening ports
echo "Current listening ports:"
netstat -tunlp

# Initialize firewall variables
IPTABLES="/sbin/iptables"
IP6TABLES="/sbin/ip6tables"
MODPROBE="/sbin/modprobe"
RMMOD="/sbin/rmmod"
ARP="/usr/sbin/arp"
SSHPORT="22"

# Logging configuration
LOG="LOG --log-level debug --log-tcp-sequence --log-tcp-options"
LOG="$LOG --log-ip-options"

# Rate limiting defaults
RLIMIT="-m limit --limit 3/s --limit-burst 8"

# Port ranges
PHIGH="1024:65535"
PSSH="1000:1023"

# Load required modules
"$MODPROBE" ip_conntrack_ftp
"$MODPROBE" ip_conntrack_irc

# Secure SSH configuration
if [ -f "/etc/ssh/sshd_config" ]; then
    echo "Hardening SSH configuration..."
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
    sed -i '\''s/#PermitRootLogin yes/PermitRootLogin no/'\'' /etc/ssh/sshd_config
    sed -i '\''s/#MaxAuthTries 6/MaxAuthTries 3/'\'' /etc/ssh/sshd_config
    sed -i '\''s/#PasswordAuthentication yes/PasswordAuthentication no/'\'' /etc/ssh/sshd_config
    sed -i '\''s/#PermitEmptyPasswords yes/PermitEmptyPasswords no/'\'' /etc/ssh/sshd_config
    sed -i '\''s/#Protocol 2/Protocol 2/'\'' /etc/ssh/sshd_config
    echo "KexAlgorithms curve25519-sha256@libssh.org,diffie-hellman-group16-sha512,diffie-hellman-group18-sha512" >> /etc/ssh/sshd_config
    echo "Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com" >> /etc/ssh/sshd_config
fi

# Kernel parameter hardening
echo "Configuring kernel parameters..."
echo 1 > /proc/sys/net/ipv4/ip_forward
echo 0 > /proc/sys/net/ipv4/ip_forward

# Additional kernel hardening
echo "kernel.core_uses_pid = 1" >> /etc/sysctl.conf
echo "kernel.dmesg_restrict = 1" >> /etc/sysctl.conf
echo "kernel.kptr_restrict = 2" >> /etc/sysctl.conf
echo "kernel.sysrq = 0" >> /etc/sysctl.conf
echo "kernel.unprivileged_bpf_disabled = 1" >> /etc/sysctl.conf
echo "net.core.bpf_jit_harden = 2" >> /etc/sysctl.conf

# IP Spoofing protection
for i in /proc/sys/net/ipv4/conf/*/rp_filter; do echo 1 > "$i"; done

# TCP/IP hardening
echo 1 > /proc/sys/net/ipv4/tcp_syncookies
echo 0 > /proc/sys/net/ipv4/icmp_echo_ignore_all
echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts
for i in /proc/sys/net/ipv4/conf/*/log_martians; do echo 1 > "$i"; done
echo 1 > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses

# Disable IP forwarding
for i in /proc/sys/net/ipv4/conf/*/accept_redirects; do echo 0 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/send_redirects; do echo 0 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/accept_source_route; do echo 0 > "$i"; done

# Disable multicast and proxy settings
for i in /proc/sys/net/ipv4/conf/*/mc_forwarding; do echo 0 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/proxy_arp; do echo 0 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/secure_redirects; do echo 1 > "$i"; done
for i in /proc/sys/net/ipv4/conf/*/bootp_relay; do echo 0 > "$i"; done

# Secure shared memory
echo "tmpfs     /dev/shm     tmpfs     defaults,noexec,nosuid,nodev     0     0" >> /etc/fstab

# Initialize iptables
echo "Configuring iptables..."
"$IPTABLES" -P INPUT DROP
"$IPTABLES" -P FORWARD DROP
"$IPTABLES" -P OUTPUT DROP

# Configure NAT/mangle tables
"$IPTABLES" -t nat -P PREROUTING ACCEPT
"$IPTABLES" -t nat -P OUTPUT ACCEPT
"$IPTABLES" -t nat -P POSTROUTING ACCEPT

"$IPTABLES" -t mangle -P PREROUTING ACCEPT
"$IPTABLES" -t mangle -P INPUT ACCEPT
"$IPTABLES" -t mangle -P FORWARD ACCEPT
"$IPTABLES" -t mangle -P OUTPUT ACCEPT
"$IPTABLES" -t mangle -P POSTROUTING ACCEPT

# Clean existing rules
"$IPTABLES" -F
"$IPTABLES" -t nat -F
"$IPTABLES" -t mangle -F
"$IPTABLES" -X
"$IPTABLES" -t nat -X
"$IPTABLES" -t mangle -X
"$IPTABLES" -Z
"$IPTABLES" -t nat -Z
"$IPTABLES" -t mangle -Z

# Disable IPv6
if test -x "$IP6TABLES"; then
    "$IP6TABLES" -P INPUT DROP 2>/dev/null
    "$IP6TABLES" -P FORWARD DROP 2>/dev/null
    "$IP6TABLES" -P OUTPUT DROP 2>/dev/null
    "$IP6TABLES" -t mangle -P PREROUTING ACCEPT 2>/dev/null
    "$IP6TABLES" -t mangle -P INPUT ACCEPT 2>/dev/null
    "$IP6TABLES" -t mangle -P FORWARD ACCEPT 2>/dev/null
    "$IP6TABLES" -t mangle -P OUTPUT ACCEPT 2>/dev/null
    "$IP6TABLES" -t mangle -P POSTROUTING ACCEPT 2>/dev/null
    "$IP6TABLES" -F 2>/dev/null
    "$IP6TABLES" -t mangle -F 2>/dev/null
    "$IP6TABLES" -X 2>/dev/null
    "$IP6TABLES" -t mangle -X 2>/dev/null
    "$IP6TABLES" -Z 2>/dev/null
    "$IP6TABLES" -t mangle -Z 2>/dev/null
fi

# Custom chains
"$IPTABLES" -N ACCEPTLOG
"$IPTABLES" -A ACCEPTLOG -j "$LOG" "$RLIMIT" --log-prefix "ACCEPT "
"$IPTABLES" -A ACCEPTLOG -j ACCEPT

"$IPTABLES" -N DROPLOG
"$IPTABLES" -A DROPLOG -j "$LOG" "$RLIMIT" --log-prefix "DROP "
"$IPTABLES" -A DROPLOG -j DROP

"$IPTABLES" -N REJECTLOG
"$IPTABLES" -A REJECTLOG -j "$LOG" "$RLIMIT" --log-prefix "REJECT "
"$IPTABLES" -A REJECTLOG -p tcp -j REJECT --reject-with tcp-reset
"$IPTABLES" -A REJECTLOG -j REJECT

"$IPTABLES" -N RELATED_ICMP
"$IPTABLES" -A RELATED_ICMP -p icmp --icmp-type destination-unreachable -j ACCEPT
"$IPTABLES" -A RELATED_ICMP -p icmp --icmp-type time-exceeded -j ACCEPT
"$IPTABLES" -A RELATED_ICMP -p icmp --icmp-type parameter-problem -j ACCEPT
"$IPTABLES" -A RELATED_ICMP -j DROPLOG

# PING rules
"$IPTABLES" -A INPUT -p icmp -m limit --limit 1/s --limit-burst 2 -j ACCEPT
"$IPTABLES" -A INPUT -p icmp -m limit --limit 1/s --limit-burst 2 -j LOG --log-prefix PING-DROP:
"$IPTABLES" -A INPUT -p icmp -j DROP
"$IPTABLES" -A OUTPUT -p icmp -j ACCEPT

# Block suspicious packets
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL NONE -j DROP
"$IPTABLES" -A INPUT -p tcp ! --syn -m state --state NEW -j DROP
"$IPTABLES" -A INPUT -p tcp --tcp-flags ALL ALL -j DROP
"$IPTABLES" -A INPUT -p tcp -m conntrack --ctstate NEW -m limit --limit 60/s --limit-burst 20 -j ACCEPT

# Block suspicious source addresses
"$IPTABLES" -A INPUT -s 169.254.0.0/16 -j DROP
"$IPTABLES" -A INPUT -s 192.0.2.0/24 -j DROP
"$IPTABLES" -A INPUT -s 224.0.0.0/4 -j DROP
"$IPTABLES" -A INPUT -d 224.0.0.0/4 -j DROP
"$IPTABLES" -A INPUT -s 240.0.0.0/5 -j DROP
"$IPTABLES" -A INPUT -d 240.0.0.0/5 -j DROP
"$IPTABLES" -A INPUT -s 0.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -d 0.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -d 239.255.255.0/24 -j DROP
"$IPTABLES" -A INPUT -d 255.255.255.255 -j DROP

# Drop IANA-reserved IPs
"$IPTABLES" -A INPUT -s 0.0.0.0/7 -j DROP
"$IPTABLES" -A INPUT -s 2.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 5.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 7.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 10.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 23.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 27.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 31.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 36.0.0.0/7 -j DROP
"$IPTABLES" -A INPUT -s 39.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 42.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 49.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 50.0.0.0/8 -j DROP
"$IPTABLES" -A INPUT -s 77.0.0.0/8 -j DROP

# Allow essential outbound connections
"$IPTABLES" -A OUTPUT -m state --state NEW -p udp --dport 53 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 53 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 80 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 443 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 587 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 995 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport "$SSHPORT" -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p tcp --dport 21 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p udp --sport 67:68 --dport 67:68 -j ACCEPT
"$IPTABLES" -A OUTPUT -m state --state NEW -p udp --dport 1194 -j ACCEPT

# Allow essential incoming connections
"$IPTABLES" -A INPUT -m state --state NEW -p udp --dport 53 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 53 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 80 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 443 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 110 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 143 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 995 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 25 -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport "$SSHPORT" -j ACCEPT
"$IPTABLES" -A INPUT -m state --state NEW -p tcp --dport 21 -j ACCEPT

# Add logging for failed connection attempts
"$IPTABLES" -A INPUT -m limit --limit 5/min -j LOG --log-prefix "iptables_INPUT_denied: " --log-level 7

# Explicitly log and reject everything else
"$IPTABLES" -A INPUT -j REJECTLOG
"$IPTABLES" -A OUTPUT -j REJECTLOG
"$IPTABLES" -A FORWARD -j REJECTLOG

# IPv6 rules
if [ -x "$IP6TABLES" ]; then
    echo "Configuring IPv6 rules..."
    ip6tables -A INPUT -p tcp --dport "$SSHPORT" -s HOST_IPV6_IP -j ACCEPT
    ip6tables -A INPUT -p tcp --dport 80 -j ACCEPT
    ip6tables -A INPUT -p tcp --dport 21 -j ACCEPT
    ip6tables -A INPUT -p tcp --dport 25 -j ACCEPT
    
    # Display IPv6 rules with line numbers
    ip6tables -L -n --line-numbers
fi

# Secure /tmp directory
if mount | grep /tmp > /dev/null; then
    echo "Securing /tmp directory..."
    mount -o remount,nodev,nosuid,noexec /tmp
fi

# Create or update login.defs security settings
echo "Updating login.defs security settings..."
sed -i '\''s/PASS_MAX_DAYS.*/PASS_MAX_DAYS   90/'\'' /etc/login.defs
sed -i '\''s/PASS_MIN_DAYS.*/PASS_MIN_DAYS   7/'\'' /etc/login.defs
sed -i '\''s/PASS_WARN_AGE.*/PASS_WARN_AGE   14/'\'' /etc/login.defs

# Add security limits
echo "Adding security limits..."
cat >> /etc/security/limits.conf << EOF
* hard core 0
* soft nproc 1000
* hard nproc 2000
EOF

# Secure cron
if [ -d "/etc/cron.allow" ]; then
    echo "Securing cron..."
    touch /etc/cron.allow
    chmod 600 /etc/cron.allow
    rm -f /etc/cron.deny
fi

# Update file access time settings
echo "Updating file access time settings..."
for fs in $(grep -v "noatime" /etc/fstab | grep "^/dev/" | cut -f1 -d" "); do
    mount -o remount,noatime "$fs"
done

# Disable uncommon network protocols
echo "Disabling uncommon network protocols..."
cat >> /etc/modprobe.d/uncommon-net-protocols.conf << EOF
install dccp /bin/true
install sctp /bin/true
install rds /bin/true
install tipc /bin/true
EOF

# Apply hardened configuration files
echo "Applying Hardened configuration files..."
apply_config "etc-aide-conf" "/etc/aide.conf"
apply_config "etc-bash-bashrc" "/etc/bash.bashrc"
apply_config "etc-crypttab" "/etc/crypttab"
apply_config "etc-default-passwd" "/etc/default/passwd"
apply_config "etc-dhclient-conf" "/etc/dhclient.conf"
apply_config "etc-hardening-wrapper-conf" "/etc/hardening-wrapper.conf"
apply_config "etc-iptables-ip6tables.rules" "/etc/iptables/ip6tables.rules"
apply_config "etc-iptables-iptables.rules" "/etc/iptables/iptables.rules"
apply_config "etc-issue" "/etc/issue"
apply_config "etc-issue-net" "/etc/issue.net"
apply_config "etc-locale-conf" "/etc/locale.conf"
apply_config "etc-locale-gen" "/etc/locale.gen"
apply_config "etc-mkinitcpio-conf" "/etc/mkinitcpio.conf"
apply_config "etc-modprobe-d-blacklist-firewire" "/etc/modprobe.d/blacklist-firewire"

# Verify important file permissions
echo "Verifying critical file permissions..."
find /etc/cron.* -type f -exec chmod 0700 {} \;
chmod 0600 /etc/crontab
chmod 0600 /etc/ssh/sshd_config 2>/dev/null
chmod -R 0700 /etc/ssl/private 2>/dev/null

# Apply sysctl changes
echo "Applying sysctl changes..."
sysctl -p

# Display completion message with timestamp
echo "Hardening configuration completed at $(date)"
echo "Please review any warnings above and reboot the system when convenient."
echo "Note: Some changes may require a system restart to take effect."

# Create a backup of important security configurations
BACKUP_DIR="/root/security_backup_$(date +%Y%m%d_%H%M%S)"
echo "Creating security configuration backup in $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
cp -p /etc/ssh/sshd_config "$BACKUP_DIR/" 2>/dev/null
cp -p /etc/sysctl.conf "$BACKUP_DIR/"
cp -p /etc/security/limits.conf "$BACKUP_DIR/"
iptables-save > "$BACKUP_DIR/iptables_backup"
ip6tables-save > "$BACKUP_DIR/ip6tables_backup" 2>/dev/null

exit 0
'
