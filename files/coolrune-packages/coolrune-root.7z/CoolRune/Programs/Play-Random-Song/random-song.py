import os
import glob
import subprocess
import random

# Ask the user to input the directory
directory = input("Enter the directory: ")

# Find all audio files in the directory and its subdirectories
audio_files = []
for extension in ['*.ogg', '*.mp3', '*.m4a', '*.opus', '*.wav']:
    audio_files.extend(glob.glob(os.path.join(directory, '**', extension), recursive=True))

# Function to play a selected audio file
def play_audio(file_path):
    subprocess.call(['ffplay', '-noborder', '-autoexit', file_path])

# Infinite loop to continuously select and play random audio files
while True:
    random_file = random.choice(audio_files)
    print(f"Playing {random_file}")
    play_audio(random_file)
